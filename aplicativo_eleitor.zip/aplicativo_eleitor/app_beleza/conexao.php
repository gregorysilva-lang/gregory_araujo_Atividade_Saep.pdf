<?php
// Dados de acesso ao banco de dados.
$servidor = "localhost";
$usuario = "root";
$senha = 'Senai@118';
$banco = "eleicao";

// Cria a conexão com o MySQL.
$conn = new mysqli($servidor, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Define o charset para aceitar acentos corretamente.
$conn->set_charset("utf8mb4");
?>
