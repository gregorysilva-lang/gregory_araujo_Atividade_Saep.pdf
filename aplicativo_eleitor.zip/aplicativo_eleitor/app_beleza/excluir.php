<?php
include "conexao.php";

$id = $_GET['id'] ?? 0;

// Prepared statement para excluir o eleitor pelo ID.
$sql = "DELETE FROM eleitor WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();

header("Location: index.php");
exit;
?>
