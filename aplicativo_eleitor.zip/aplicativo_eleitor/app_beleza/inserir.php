<?php
include "conexao.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $numero_titulo = $_POST['numero_titulo'];
    $cidade = $_POST['cidade'];

    // Prepared statement para inserir o eleitor com segurança.
    $sql = "INSERT INTO eleitor (nome, numero_titulo, cidade) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nome, $numero_titulo, $cidade);
    $stmt->execute();
    $stmt->close();
}

header("Location: index.php");
exit;
?>
