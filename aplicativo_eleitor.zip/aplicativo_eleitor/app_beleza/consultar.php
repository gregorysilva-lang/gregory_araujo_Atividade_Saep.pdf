<?php
include "conexao.php";

$id = $_GET['id'] ?? 0;

// Busca um eleitor pelo ID informado na URL.
$sql = "SELECT * FROM eleitor WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();
$eleitor = $resultado->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar Eleitor</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="cabecalho">
        <h1>Sistema de Eleitores</h1>
        <p>Detalhes do eleitor</p>
    </header>

    <main class="conteudo">
        <section class="painel detalhes">
            <?php if ($eleitor): ?>
                <h2>Eleitor cadastrado</h2>
                <p><strong>ID:</strong> <?= htmlspecialchars($eleitor['id']) ?></p>
                <p><strong>Nome:</strong> <?= htmlspecialchars($eleitor['nome']) ?></p>
                <p><strong>Número do título:</strong> <?= htmlspecialchars($eleitor['numero_titulo']) ?></p>
                <p><strong>Cidade:</strong> <?= htmlspecialchars($eleitor['cidade']) ?></p>
            <?php else: ?>
                <h2>Eleitor não encontrado.</h2>
            <?php endif; ?>

            <a class="botao botao-voltar" href="index.php">Voltar</a>
        </section>
    </main>
</body>
</html>
