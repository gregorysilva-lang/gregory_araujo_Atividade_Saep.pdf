<?php
include "conexao.php";

// Busca todos os eleitores cadastrados.
$resultado = $conn->query("SELECT * FROM eleitor ORDER BY id");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Eleitores</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="cabecalho">
        <h1>Sistema de Eleitores</h1>
        <p>Cadastro de Eleitores</p>
    </header>

    <main class="conteudo">
        <section class="painel">
            <h2>Cadastrar eleitor</h2>
            <form action="inserir.php" method="POST" class="formulario">
                <label for="nome">Nome</label>
                <input type="text" id="nome" name="nome" maxlength="100" required>

                <label for="numero_titulo">Número do título</label>
                <input type="text" id="numero_titulo" name="numero_titulo" maxlength="20" required>

                <label for="cidade">Cidade</label>
                <input type="text" id="cidade" name="cidade" maxlength="100" required>

                <button type="submit" class="botao botao-cadastrar">Cadastrar eleitor</button>
            </form>
        </section>

        <section class="painel">
            <h2>Eleitores cadastrados</h2>
            <div class="tabela-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Telefone</th>
                            <th>Cidade</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($eleitor = $resultado->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($eleitor['id']) ?></td>
                                <td><?= htmlspecialchars($eleitor['nome']) ?></td>
                                <td><?= htmlspecialchars($eleitor['numero_titulo']) ?></td>
                                <td><?= htmlspecialchars($eleitor['cidade']) ?></td>
                                <td class="acoes">
                                    <a class="botao botao-consultar" href="consultar.php?id=<?= $eleitor['id'] ?>">Consultar</a>
                                    <a class="botao botao-excluir" href="excluir.php?id=<?= $eleitor['id'] ?>" onclick="return confirm('Deseja realmente excluir este eleitor?');">Excluir</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</body>
</html>
